import javax.sound.sampled.*;
import java.io.*;

public class PlaySound{
    String str="";
    PlaySound(String sound){
        str+=sound;
    } 
    public void play() throws Exception{
        try{
            Clip clip;
            AudioInputStream audioInputStream=AudioSystem.getAudioInputStream(new File("Sounds/"+str+".wav"));
            clip=AudioSystem.getClip(null);
            clip.open(audioInputStream);
            clip.start();
            //clip.loop(0);
            clip.loop(0);
            //clip.close();
        } catch(Exception e){
            System.out.println("Hey");
        }
    }
}