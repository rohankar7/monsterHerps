import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.imageio.ImageIO;

import java.awt.image.BufferedImage;
import java.io.*;
import java.util.LinkedList;

public class GamePanel extends JPanel implements KeyListener,MouseListener,Runnable{
    // Classes
    Collision col=new Collision();
    Ball fireBall;
    Dragon dr;
    Thread t;
    Dialogue dialog;
    PlaySound weaponSound;
    PlaySound fireball;
    //Weapon definitions
    Weapon kunai;
    LinkedList <Weapon> kunais;
    private int shot;
    private boolean thrownKunai=false,alreadyThrown=false;
    //Variables
    private boolean running=false,pause=false,trigger=true,started=false;
    private String buff[];
    private boolean over=false;
    private volatile boolean enteredGate=false;
    volatile int up,down,left,right;                   //directions
    int x,y;
    int key;
    int yoffset,offsetCount,downOffsetCount;
    volatile int velx,vely;
    private int hitCount;
    int count;
    //Dialogue inits
    private int dialogueTime=0;
    private boolean showingDalogue=false;
    private int dialogueCount=0;
    //Image definitions
    BufferedImage frog,title1,title2;
    BufferedImage dragon2,dragon1;
    BufferedImage ball;
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    GamePanel(){
        System.out.println("Hello");
        addMouseListener(this);
        addKeyListener(this);
        setFocusable(true);
        requestFocus();
        setFocusTraversalKeysEnabled(false);
        initGame();
        t=new Thread(this);
        kunais=new LinkedList<Weapon>();
        t.start();
        weaponSound=new PlaySound("weaponThrown");
        fireball=new PlaySound("fireball");
        dialog=new Dialogue();
        try{
            preload();
        } catch(IOException e){}
    }

///////////////////////////////////////////////////////////////////
protected void preload() throws IOException{
    frog=ImageIO.read(new File("Images/frog.png"));
    title1=ImageIO.read(new File("Images/name.png"));
    title2=ImageIO.read(new File("Images/name1.png"));
    dragon1=ImageIO.read(new File("Images/Dragon11.png"));
    dragon2=ImageIO.read(new File("Images/Dragon12.png"));
    ball=ImageIO.read(new File("Images/ball.png"));
}
///////////////////////////////////////////////////////////////////

@Override
    public void keyPressed(KeyEvent ke){
        key=ke.getExtendedKeyCode();
        if(key==KeyEvent.VK_UP && !pause && started && !showingDalogue){
            if(col.forestCollided(offsetCount, 0, x, y)==true){
                vely=4;
                col.change();
                 //
            }
            else{
                if(col.skyLand(offsetCount, y)==false){     //check whether the character collides with the horizon
                    vely=-4;
                }
                else{
                    vely=4;
                    col.change();
                }
                 //
            }
            ++up;
            down=left=right=0;
            velx=0;
        }
        else if(key==KeyEvent.VK_DOWN && !pause && started && !showingDalogue){
            if(col.forestCollided(offsetCount, 2, x, y)){
                vely=-4;
                col.changeBottom();
                 
            }
            else{
                if(col.boundaryBottom(offsetCount,y)==false){
                    vely=4;
                }
                else{
                    vely=-4;
                    col.changeBottom();
                }
                 //
            }
            ++down;
            up=left=right=0;
            velx=0;
        }
        else if(key==KeyEvent.VK_LEFT && !pause && started && !showingDalogue){
            if(col.forestCollided(offsetCount, 1, x, y)==true){
                velx=4;
                col.changeLeft();
                 
            }
            else{
                if(col.boundaryLeft(offsetCount,x)==false){          //check whether the character collides with the left wall
                    velx=-4;
                } 
                else{
                    velx=4;
                    col.changeLeft();
                }
                 //
            }
            ++left;
            down=up=right=0;
            vely=0;
        }
        else if(key==KeyEvent.VK_RIGHT && !pause && started && !showingDalogue){
            if(col.forestCollided(offsetCount, 3, x, y)==true){
                velx=-4;
                col.changeRight();
                 
            }
            else{
                if(col.boundaryRight(offsetCount,x)==false){
                    velx=4;
                }
                else{
                    velx=-4;
                    col.changeRight();
                }
                 //
            }
            ++right;
            down=left=up=0;
            vely=0;
        }
        else if(key==KeyEvent.VK_ESCAPE  && started){
            if(pause==true){
                pause=false;
            }
            else if(over==true){
                exitWindow();
            }
            else pause=true;
        }
        else if(key==KeyEvent.VK_ENTER){
            if(over){
                initGame();
            }
            else if(!started){
                started=true;
            }
            else ++dialogueCount;
            
        }
        else if(key==KeyEvent.VK_SPACE){
            if(showingDalogue){
                dialogueCount=buff.length;
            }
        }
        else{
            velx=vely=0;
        }
        x+=velx;
        y+=vely;
    }

////////////////////////////////////////////////////////////

@Override
public void keyTyped(KeyEvent ke){
    key=ke.getExtendedKeyCode();
    if(key==KeyEvent.VK_UP && !pause && started && !showingDalogue){
        if(col.forestCollided(offsetCount, 0, x, y)==true){
            vely=4;
            col.change();
             //
        }
        else{
            if(col.skyLand(offsetCount, y)==false){     //check whether the character collides with the horizon
                vely=-4;
            }
            else{
                vely=4;
                col.change();
            }
             //
        }
        ++up;
        down=left=right=0;
        velx=0;
    }
    else if(key==KeyEvent.VK_DOWN && !pause && started && !showingDalogue){
        if(col.forestCollided(offsetCount, 2, x, y)){
            vely=-4;
            col.changeBottom();
             
        }
        else{
            if(col.boundaryBottom(offsetCount,y)==false){
                vely=4;
            }
            else{
                vely=-4;
                col.changeBottom();
            }
             //
        }
        ++down;
        up=left=right=0;
        velx=0;
    }
    else if(key==KeyEvent.VK_LEFT && !pause && started && !showingDalogue){
        if(col.forestCollided(offsetCount, 1, x, y)==true){
            velx=4;
            col.changeLeft();
             
        }
        else{
            if(col.boundaryLeft(offsetCount,x)==false){          //check whether the character collides with the left wall
                velx=-4;
            } 
            else{
                velx=4;
                col.changeLeft();
            }
             //
        }
        ++left;
        down=up=right=0;
        vely=0;
    }
    else if(key==KeyEvent.VK_RIGHT && !pause && started && !showingDalogue){
        if(col.forestCollided(offsetCount, 3, x, y)==true){
            velx=-4;
            col.changeRight();
             
        }
        else{
            if(col.boundaryRight(offsetCount,x)==false){
                velx=4;
            }
            else{
                velx=-4;
                col.changeRight();
            }
             //
        }
        ++right;
        down=left=up=0;
        vely=0;
    }
    else if(key==KeyEvent.VK_ESCAPE  && started){
        if(pause==true){
            pause=false;
        }
        else if(over==true){
            exitWindow();
        }
        else pause=true;
    }
    else if(key==KeyEvent.VK_ENTER){
        if(over){
            initGame();
        }
        else if(!started){
            started=true;
        }
        else ++dialogueCount;
        
    }
    else if(key==KeyEvent.VK_SPACE){
        if(showingDalogue){
            dialogueCount=buff.length;
        }
    }
    else{
        velx=vely=0;
    }
    x+=velx;
    y+=vely;
}

    @Override
    public void keyReleased(KeyEvent ke){
        if(down>0){
            up=left=right=0;
        }
        else if(up>0){
            down=left=right=0;
        }
        else if(right>0){
            down=up=left=0;
        }
        else if(left>0){
            right=up=down=0;
        }
    }
    public void exitWindow(){
        System.exit(0);
    }

    @Override
    public void mouseClicked(MouseEvent arg0) {
        if(!showingDalogue){
            try{
                weaponSound.play();
            } catch(Exception e){}
            addKunai(new Weapon(x,y));
            thrownKunai=true;
        }
    }

    @Override
    public void mouseEntered(MouseEvent arg0) {
        // TODO Auto-generated method stub
        System.out.println("Hey");

    }

    @Override
    public void mouseExited(MouseEvent arg0) {
        // TODO Auto-generated method stub
        System.out.println("Hey");


    }

    @Override
    public void mousePressed(MouseEvent arg0) {
        // TODO Auto-generated method stub
    }

    @Override
    public void mouseReleased(MouseEvent arg0) {
        // TODO Auto-generated method stub
    }    
    @Override
    public void paint(Graphics g){
        super.paintComponent(g);
        Toolkit d=Toolkit.getDefaultToolkit();
        //DrawImages
        Toolkit D=Toolkit.getDefaultToolkit();
        Toolkit tool=Toolkit.getDefaultToolkit();
        Image finish=tool.getImage("Images/gameOver.png");
        Image demo[]=new Image[2];
        demo[0]=d.getImage("Images/character1.png");
        demo[1]=d.getImage("Images/character2.png");
        Image paused=D.getImage("Images/paused.png");
        if(started){
            try{
                BufferedImage grass=ImageIO.read(new File("Images/grass1.png"));
                g.drawImage(grass,0,-960-yoffset,960,1920,null);
            } catch(IOException e){}
    
            
            //Change the collision coordinates
            if(right!=0){
                if(col.forestCollided(offsetCount, 3, x, y)==true){
                    x-=4;
                }
            }
            else if(left!=0){
                if(col.forestCollided(offsetCount, 1, x, y)==true){
                    x+=4;
                }
            }
            //Game is running
            if(!pause && !over){
                if(y<=60){
                    yoffset-=120;
                    y+=120;
                    ++offsetCount;
        
                    if(offsetCount==4){
                        dr=new Dragon();
                        yoffset-=480;
                        y+=480;
                        
                    }
                    System.out.println("offsetCount: "+offsetCount);
                }
                if(y>=836 && offsetCount!=0 && offsetCount!=4){
                    yoffset+=120;
                    y-=120;
                    --offsetCount;
                    System.out.println("offsetCount: "+offsetCount);
                }
                
                if(offsetCount==4){
                    showingDalogue=true;
                    buff=dialog.introDragon();
                    if(showingDalogue && dialogueTime==0){
                        if(dialogueCount<buff.length){
                            g.fillRect(0,0,960,960);
                            g.setColor(Color.white);
                            g.fillRect(0, 900, 960, 60);
                            g.setColor(Color.BLACK);
                            g.drawString(buff[dialogueCount],100, 915);
                        }
                        else{
                            showingDalogue=false;
                            dialogueCount=0;
                            ++dialogueTime;
                        }
                    }
                    else{
                        showingDalogue=false;
                        if(dr.getVar()%2==0){
                            g.drawImage(dragon1,200,dr.getVar(),null);
                        }
                        else{
                            g.drawImage(dragon2,200,dr.getVar(),null);
                        }
                        //Draw the health bars and the background for them
                        g.setColor(Color.white);
                        g.setFont(new Font("SansSerif",Font.PLAIN,16));
                        g.drawString("Dragon", 200, 24);
                        g.drawString("Player", 200, 56);
                        //Health Background
                        g.setColor(Color.BLACK);
                        g.fillRoundRect(300, 16, 512, 16, 4, 4);
                        g.fillRoundRect(300,48,128,16,4,4);
                        //Dark Green=003a00
                        Color health=new Color(0,58,0);
                        int calc=128-(hitCount*16);
                        g.setColor(health);
                        g.fillRoundRect(300, 16, 512-(16*shot), 16, 4, 4);
                        g.fillRoundRect(300,48,calc,16,4,4);
                        //over or not
                        if(calc==0 || (512-(16*shot))==0){
                            over=true;
                            //running=false;
                        }
            
                        //Work on the drawing the fireballs on the stage
                        if(trigger){
                            fireBall=new Ball(x,y,400,dr.getVar()+200);
                            try{
                                fireball.play();
                            } catch(Exception e){}
                            ++count;
                            fireBall.setvisible(true);
                            trigger=false;
                        }
                        //kunai hits dragon
                        Weapon k;
                        if(alreadyThrown){
                            for(int number=0;number<kunais.size();number++){
                                k=kunais.get(number);
                                if(k.visible){
                                    if(k.hitsEnemy(dr.getVar())){
                                        ++shot;
                                        k.visible=false;
                                    }
                                }
                            }
                        }
                        //fireball hits player
                        if(fireBall.visibility()){
                            g.drawImage(ball, fireBall.ballX, fireBall.ballY, null);
                            if(fireBall.hitsPlayer(x, y)==true){
                                if(col.boundaryBottom(offsetCount,y)==false){
                                    y+=16;
                                }
                                else{
                                    y+=-16;
                                    col.changeBottom();
                                }
                                hitCount++;
                            }
                        }
                        else{
                            trigger=true;
                            fireBall.setvisible(false);
                        }
                    }
                }
                //Draw the dialogues
                if(offsetCount==0){
                    buff=dialog.story();
                    if(showingDalogue){
                        if(dialogueCount<buff.length){
                            g.setColor(Color.white);
                            g.fillRect(0, 900, 960, 60);
                            g.setColor(Color.BLACK);
                            g.drawString(buff[dialogueCount],100, 915);
                            //g.clearRect(arg0, arg1, arg2, arg3);
                        }
                            
                        else{
                            showingDalogue=false;
                            dialogueCount=0;
                        }
                    }
                }
                //Draw the gate
                if(offsetCount==3){
                    g.drawImage(Toolkit.getDefaultToolkit().getImage("Images/gate.png"),960/2-96,0,null);
                    if(y<176 && !enteredGate){
                        if(x<440 || x>472){
                            y=176;
                            enteredGate=false;
                        }
                        else if(x>440 && x<=472){
                            if(y<=160){
                                enteredGate=true;
                            }
                            else{
                                enteredGate=false;
                            }
                        }
                    }
                    else if(enteredGate && y<176){
                        if(x<440){
                            x=440;
                        }
                        else if(x>472){
                            x=472;
                        }
                    }
                    else{
                        enteredGate=false;
                    }
                }
    
                //Draw the player
                if(up>down){
                    g.drawImage(demo[0],x,y,null);
                }
                else{
                    g.drawImage(demo[1],x,y,null);
                }
    
                // Draw the kunai knives
                for(int q=0;q<kunais.size();q++){
                    kunai=kunais.get(q);
                    if(thrownKunai){
                        alreadyThrown=true;
                    }
                    if(!kunai.isVisible()){
                        removeKunai(kunai);
                    }
                    else{
                        g.drawImage(kunai.getKunai(),kunai.kx,kunai.ky,null);
                        System.out.println(kunais.size());
                    }
                }
            }
            else if(over){
                g.setColor(Color.white);
                g.fillRect(0, 0, 960, 960);
                g.drawImage(finish,240,240,null);
                g.drawImage(Toolkit.getDefaultToolkit().getImage("Images/Options.png"),240,640,null);
            }
            else{     //Draw the Pause image above all stages
                g.drawImage(paused,240,240,null);
            }
        }
        else{
            setBackground(Color.BLACK);
            g.drawImage(title1, 60, 180, 960, 960, null);
        }
    }
   
    protected void initGame(){
        count=0; hitCount=0; velx=0; vely=0;
        up=0; down=0; left=0; right=0;
        x=448; y=848;
        yoffset=0; offsetCount=0; downOffsetCount=0;
        running=true;
        over=false;
        pause=false;
        trigger=true;
        showingDalogue=true;
        shot=0;
        started=false;
        dialogueTime=0;
    }
    public void addKunai(Weapon weapon){
        kunais.add(weapon);
    }
    public void removeKunai(Weapon weapon){
        kunais.remove(weapon);
    }
    @Override
    public void run() {        
        while(running){
            try{
                repaint();
                Thread.sleep(30);  
            } catch(InterruptedException e){}
        }
    }
}