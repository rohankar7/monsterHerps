import java.awt.*;

public class Weapon implements Runnable{
    private boolean hit=false;
    protected int kx,ky,kdistance;
    protected volatile boolean visible=false;
    Thread t;
    Image img;
    Weapon(int x,int y){
        visible=true;
        kx=x+24; ky=y-16;
        kdistance=0;
        t=new Thread(this);
        t.start();
    }
    protected boolean hitsEnemy(int dragony){
        if(ky<=dragony+200 && kx>=212 && kx<=696){
            hit=true;
            visible=false;
        }
        else{
            hit=false;
            visible=true;
        }
        return hit;
    }
    public Image getKunai(){
        Toolkit tool=Toolkit.getDefaultToolkit();
        img=tool.getImage("Images/kunai.png");
        return img;
    }
    protected boolean dropKunai(){
        visible=false;
        return visible;
    }

    protected boolean isVisible(){
        return visible;
    }

    public void run(){
        while(visible){
            try{
                Thread.sleep(20);
            } catch(InterruptedException e){}
            if(visible){
                throwKunai();
            }
            
        }
    }
    protected void throwKunai(){
        if(kdistance!=512 && !hit){
            kdistance+=4;
            ky-=4;
        }
        else{
            visible=false;
            kdistance=0;
        }  
    }
}