//import java.awt.*;
import javax.swing.*;

class Game extends JFrame{
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    Game(String title) {
        super(title);
    }
    public static void main(String args[]){
        Game id=new Game("MyGame");
        GamePanel gp=new GamePanel();
        //PlaySound p=new PlaySound();
        id.add(gp);
        id.setResizable(false);
        id.setVisible(true);
        id.setSize(960,960);
        id.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        /*try{
            p.play();
        } catch(Exception e){}*/
    }
}