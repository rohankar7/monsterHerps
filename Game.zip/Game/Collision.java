public class Collision{
	private int level;
    private boolean skyFlag=false,bottomBoundFlag=false;
    private boolean leftBoundFlag=false,rightBoundFlag=false;
    //private boolean flagForest=false;
    Collision(){
        
    }
    boolean skyLand(int offsetCount,int y){
        level=offsetCount;
        if(level==4){
            if(y<=636){
                skyFlag=true;
            }
        }
        return skyFlag;
    }
    boolean boundaryLeft(int offsetCount,int x){
        if(x<=0){
            leftBoundFlag=true;
        }
        return leftBoundFlag;
    }
    boolean boundaryRight(int offsetCount,int x){
        if(x>=896){
            rightBoundFlag=true;
        }
        return rightBoundFlag;
    }
    boolean boundaryBottom(int offsetCount,int y){
        level=offsetCount;
        if(level==0 || level==4){
            if(y>=860){
                bottomBoundFlag=true;
            }
        }
        return bottomBoundFlag;
    }

    boolean forestCollided(int offsetCount,int key, int x,int y){
        boolean flag=false;
        level=offsetCount;
        if(level==0){
            if(x<268 && y<768 && y>232 && key==1){
                flag=true;
                //System.out.println("left collision");
            }
            else if(x>624 && y<768 && y>232 && key==3){
                flag=true;
                //System.out.println("right collision");
            }
            else if((x>624 || x<268) && y<=768 && y>232 && key==0){
                flag=true;
            }
            else if((x>624 || x<268) && y>=232 && y<768 && key==2){
                flag=true;
            }
            else{
                flag=false;
            }
        }
        /*offsetCount=1;
        xleft=272;
        xright=624;
        yup=352;
        */
        else if(level==1){
            if(x<268 && y>352 && key==1){
                flag=true;
                //System.out.println("left collision");
            }
            else if(x>624 && y>352 && key==3){
                flag=true;
                //System.out.println("right collision");
            }
            else if((x>624 || x<268) && y>=352 && key==2){
                flag=true;
            }
            else{
                flag=false;
            }
        }
        else if(level==2){
            if(x<268 && y>472 && key==1){
                flag=true;
                //System.out.println("left collision");
            }
            else if(x>624 && y>472 && key==3){
                flag=true;
                //System.out.println("right collision");
            }
            else if((x>624 || x<268) && y>=472 && key==2){
                flag=true;
            }
            else{
                flag=false;
            }
        }
        else if(level==3){
            if(x<268 && y>592 && key==1){
                flag=true;
                //System.out.println("left collision");
            }
            else if(x>624 && y>592 && key==3){
                flag=true;
                //System.out.println("right collision");
            }
            else if((x>624 || x<268) && y>=592 && key==2){
                flag=true;
            }
            else{
                flag=false;
            }
        }
        
        return flag;
    }

    void change(){
        skyFlag=false;
    }
    void changeLeft(){
        leftBoundFlag=false;
    }
    void changeRight(){
        rightBoundFlag=false;
    }
    void changeBottom(){
        bottomBoundFlag=false;
    }
}