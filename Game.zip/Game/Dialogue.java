class Dialogue{
    protected String[] story(){
        String str[]={"Wow! It has been a long while since I left the village.","I guess everyone will be surprised to see me all of a sudden.","Four long years and yet there isn't any sign of change!"};
        return str;
    }
    protected void elder(){
	String strcon="";	
    }
    protected String[] introDragon(){
        String charDialogues[]={"Wooo! Holy darkness! Why am I blinded all of a sudden?","Curse the creator for putting me through this.","The gate wasn't creepy at all.Then why is this it....","What do you think you are doing here, you.....insect?","Who are you... and... why do you think that this darkness shall scare me to death?","You must be a gump if you think this is some kind of mario game and you are here to rescue your princess and complete your quest. Looking at a nerd like you I am sure that you won't have a princess either"};
        return charDialogues;
    }
}
