public class Ball implements Runnable{
    private boolean agitated,stuck=false;
    protected boolean visible=false;
    Thread t;
    private int playerX,playerY,dragonX,dragonY;
    int ballX=0,ballY=0;
    Ball(int playerX,int playerY,int dragonX,int dragonY){
        this.playerX=playerX;
        this.playerY=playerY;
        this.dragonX=dragonX;
        this.dragonY=dragonY;
        ballX=dragonX;
        ballY=dragonY;
        t=new Thread(this);
        t.start();
    }

    public boolean hitsPlayer(int x,int y){
        if(ballX<x){
            if(ballX+32>=x && ballY+32>=y){
                stuck=true;
            }
            else stuck=false;
        }
        else{
            if(x+32>=ballX  && ballY+32>=y){
                stuck=true;
            }
            else stuck=false;
        }
        return stuck;
    }
    protected void setvisible(boolean flag){
        visible=flag;
    }

    protected boolean visibility(){
        return visible;
    }
    public void run(){
        agitated=true;
        while(agitated){
            try{
                Thread.sleep(10);
            } catch(InterruptedException e){}
            if(ballY-16<=playerY)
                throwBall();
            else{ 
                visible=false; 
                agitated=false;
            }
        } 
    }
    protected void throwBall(){
        double slopeX,slopeY;
        slopeY=playerY-dragonY;
        if(playerX>dragonX){
            slopeX=playerX-dragonX;
            ballX=playerX-(int)((playerY-ballY)*(slopeX/slopeY));

        }
        else{
            slopeX=dragonX-playerX;
            ballX=playerX-(int)((ballY-playerY)*(slopeX/slopeY));
        }
        ballY+=4;
        ///////////////////
    }
}