class Dragon implements Runnable{
    int var=11;
    int position=0;
    Thread t=new Thread(this);
    Dragon(){
        t.start();
    }
    int getVar(){
        return position;
    }
    public void run(){
        boolean flag=true;
        while(flag){
            try{
                Thread.sleep(500);  
            } catch(InterruptedException e){}
            position+=var;
            if(position<0 || position>200) var=-var;
            //position=150;
        }
    }
}